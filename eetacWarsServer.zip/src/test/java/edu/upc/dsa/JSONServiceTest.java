package edu.upc.dsa;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by juan on 16/11/16.
 */
public class JSONServiceTest {
    @Test
    public void getTrack() throws Exception {

    }

    @Test
    public void getTrackInJSON() throws Exception {

    }

    @Test
    public void createTrackInJSON() throws Exception {

    }

}