package edu.upc.dsa.models;

public class MapFullException extends Exception{

}
