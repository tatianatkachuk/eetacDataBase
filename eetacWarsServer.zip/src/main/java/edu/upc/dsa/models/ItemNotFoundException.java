package edu.upc.dsa.models;

public class ItemNotFoundException extends Exception {
}
