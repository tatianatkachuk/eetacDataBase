package edu.upc.dsa.models;

public class AllyNotFoundException extends Exception {
}
