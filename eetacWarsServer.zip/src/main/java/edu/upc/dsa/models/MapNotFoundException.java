package edu.upc.dsa.models;

public class MapNotFoundException extends Exception {
}
