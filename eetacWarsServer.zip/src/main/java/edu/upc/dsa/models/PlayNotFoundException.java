package edu.upc.dsa.models;

public class PlayNotFoundException extends Exception {
}
