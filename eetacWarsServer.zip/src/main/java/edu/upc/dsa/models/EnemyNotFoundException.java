package edu.upc.dsa.models;

public class EnemyNotFoundException extends Exception {
}
